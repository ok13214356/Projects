# Gatehouse — Local Site & Keyword Blocker

A Chrome extension that blocks websites, keywords in URLs, and keywords in
page content, with daily time limits and a customizable block page —
password protected, entirely local. There is no server, no analytics, and
no network request of any kind; all settings, usage counters, and your
password hash live in Chrome's local extension storage on this computer only.

## Install it (load unpacked)

1. Open `chrome://extensions` in Chrome (or any Chromium browser — Edge,
   Brave, etc. use the same page under their own name).
2. Turn on **Developer mode** (toggle, top right).
3. Click **Load unpacked**.
4. Select this folder (`local-blocker-extension`).
5. The Gatehouse icon appears in your toolbar. Click it, then **Open
   dashboard** to set your password and start adding sites/keywords.

To update the extension after editing any file, go back to
`chrome://extensions` and click the refresh icon on the Gatehouse card.

## What it does

- **Blocked websites** — block a whole domain (and its subdomains), enforced
  by Chrome's built-in `declarativeNetRequest` engine before the page loads.
- **Blocked URL keywords** — block any page whose address contains a given
  word or fragment (e.g. `/shorts`, `gambling`).
- **Blocked content keywords** — a content script scans each page's visible
  text after it loads (and watches for new content on single-page apps); if
  a banned word appears, the page is replaced with the blocked screen before
  you can read it.
- **Time limits** — give any site a daily minutes budget on the dashboard.
  While a limited page is genuinely visible and focused, it sends a
  heartbeat every 5 seconds and Gatehouse adds the real elapsed wall-clock
  time between beats (capped, so a sleeping laptop can't dump a huge chunk
  in at once). The moment the budget runs out the page blocks itself
  immediately — no reload needed — and it resets automatically at midnight.
  The same immediate redirect happens if you add a site to the blocked-sites
  list while it's already open in a tab.
- **Floating time-left widget** — while you're on a site with a time limit,
  a small, semi-transparent widget appears in the corner of the page
  showing the countdown. Drag it by its header to move it anywhere on the
  page (its position is remembered), and click the × to dismiss it — closing
  it only hides the widget, tracking and blocking carry on. It's injected
  into an isolated shadow DOM so it can't be affected by, or interfere with,
  the page's own styles. The countdown pauses when the tab isn't focused.
- **Block page editor** — customize the stamp text, heading, and an optional
  message shown whenever a page is blocked, with a live preview on the
  dashboard.
- **Password, dashboard-only** — a password (stored only as a salted
  PBKDF2-SHA256 hash, 100,000 iterations) gates the dashboard where lists,
  time limits, and the block page are edited. This is the *only* place
  Gatehouse ever asks for a password — the blocked page itself has no
  password field and cannot unlock anything on its own.
- **Auto-lock** — the dashboard locks itself again after 1 minute of
  inactivity. Any click, keystroke, or scroll while it's open resets the
  countdown, so it only locks if you actually walk away.
- **Temporary unlock, from the dashboard** — the dashboard's Security tab
  lets you unlock any domain for 5 minutes to an hour, whatever blocked it
  (site list, URL keyword, content keyword, or time limit). Since unlocking
  requires opening the dashboard, it's always behind your password.

## Notes and limitations

- Only main-page navigations are blocked (not sub-resources like images or
  scripts), so a keyword match won't accidentally break unrelated sites that
  merely load a resource with that name in its path.
- Content-keyword scanning only runs in the top-level frame, not inside
  ads/embeds, to keep things fast and avoid false positives from iframes.
- Site and time-limit blocks are enforced in three independent layers, so no
  single failure lets a site through: Chrome's request-blocking rules, a
  navigation listener in the background script, and a check the content
  script runs on every page load. URL keyword blocks rely on the first layer
  only (a keyword isn't tied to one domain), so those apply on the next
  navigation or reload.
- Time tracking is accurate to about 5 seconds, and only counts while the
  tab is actually focused and visible. Pages where content scripts can't run
  (`chrome://` pages, the Chrome Web Store, PDF viewers) aren't tracked.
- There is no password recovery. If you forget it, remove and reinstall the
  extension in `chrome://extensions` — this clears all saved lists and lets
  you start fresh.
- The icons in `icons/` are simple placeholders generated for this project —
  swap in your own `icon16.png` / `icon48.png` / `icon128.png` any time.

## File overview

| File | Purpose |
|---|---|
| `manifest.json` | Extension configuration (Manifest V3) |
| `background.js` | Service worker: builds blocking rules, tracks time usage, handles password hashing/verification, midnight reset |
| `content.js` | Scans page text for blocked content keywords |
| `popup.html/js/css` | Toolbar popup — quick status view |
| `options.html/js/css` | Password-gated dashboard: lists, time limits, block page editor, security |
| `blocked.html/js/css` | The page shown when something is blocked — no password field |
