document.addEventListener("DOMContentLoaded", async () => {
  const data = await chrome.storage.local.get([
    "protectionEnabled",
    "blockedSites",
    "urlKeywords",
    "contentKeywords"
  ]);
  const enabled = data.protectionEnabled !== false;

  const statusEl = document.getElementById("status");
  statusEl.textContent = enabled ? "Protection is on" : "Protection is off";
  statusEl.classList.add(enabled ? "on" : "off");

  document.getElementById("siteCount").textContent = (data.blockedSites || []).length;
  document.getElementById("urlKwCount").textContent = (data.urlKeywords || []).length;
  document.getElementById("contentKwCount").textContent = (data.contentKeywords || []).length;

  document.getElementById("openOptions").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
});
