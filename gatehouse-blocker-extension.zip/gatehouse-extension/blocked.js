// blocked.js
// This page never asks for a password and cannot unlock anything by itself.
// Unlocking only happens from the dashboard (options.html), which is the
// sole place Gatehouse ever requests your password.

const params = new URLSearchParams(location.search);
const reason = params.get("reason");
const originalUrl = params.get("url") || "";
const siteParam = params.get("site") || "";
const kw = params.get("kw") || "";

function hostnameOf(url) {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  } catch (e) {
    return "";
  }
}

const domain = siteParam || hostnameOf(originalUrl);

function reasonText() {
  if (reason === "site") return `"${domain}" is on your blocked sites list.`;
  if (reason === "urlkeyword") return `The web address contains a blocked keyword: "${kw}".`;
  if (reason === "content") return `This page's content contains a blocked keyword: "${kw}".`;
  if (reason === "timelimit") return `You've reached today's time limit for "${domain}". It unlocks again tomorrow.`;
  return "This page was stopped by your local blocking rules.";
}

document.getElementById("reason").textContent = reasonText();

chrome.storage.local.get("blockPageConfig", ({ blockPageConfig }) => {
  const cfg = blockPageConfig || {};
  document.getElementById("stamp").textContent = (cfg.stamp || "BLOCKED").toUpperCase();
  document.getElementById("title").textContent = cfg.heading || "This page has been stopped";
  const msgEl = document.getElementById("customMessage");
  if (cfg.message) {
    msgEl.textContent = cfg.message;
    msgEl.style.display = "block";
  }
});

document.getElementById("backBtn").addEventListener("click", () => {
  if (history.length > 1) history.back();
  else location.href = "about:blank";
});

document.getElementById("dashboardBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});
