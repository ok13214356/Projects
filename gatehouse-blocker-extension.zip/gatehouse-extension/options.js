const $ = sel => document.querySelector(sel);
const $all = sel => document.querySelectorAll(sel);

function sendMsg(msg) {
  return chrome.runtime.sendMessage(msg);
}

function normalizeDomain(raw) {
  if (!raw) return "";
  let d = raw.trim().toLowerCase();
  d = d.replace(/^https?:\/\//, "");
  d = d.split("/")[0];
  d = d.replace(/^www\./, "");
  return d;
}

function todayDateStr() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// ---------------------------------------------------------------------------
// Auth gate — the ONLY place in this whole extension that asks for a password
// ---------------------------------------------------------------------------

async function initAuth() {
  const { hasPassword } = await sendMsg({ type: "AUTH_STATUS" });
  if (hasPassword) {
    $("#loginForm").classList.remove("hidden");
    $("#loginPassword").focus();
  } else {
    $("#setupForm").classList.remove("hidden");
    $("#newPassword").focus();
  }
}

$("#setupBtn").addEventListener("click", async () => {
  const p1 = $("#newPassword").value;
  const p2 = $("#newPassword2").value;
  const err = $("#authError");
  err.textContent = "";
  if (p1 !== p2) {
    err.textContent = "Passwords do not match.";
    return;
  }
  const resp = await sendMsg({ type: "AUTH_SETUP", password: p1 });
  if (resp.ok) unlockDashboard();
  else err.textContent = resp.error || "Could not set password.";
});

$("#loginBtn").addEventListener("click", async () => {
  const p = $("#loginPassword").value;
  const err = $("#authError");
  err.textContent = "";
  const resp = await sendMsg({ type: "AUTH_VERIFY", password: p });
  if (resp.ok) unlockDashboard();
  else err.textContent = resp.error || "Incorrect password.";
});

$all("#setupForm input, #loginForm input").forEach(inp => {
  inp.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      const btn = inp.closest("div").querySelector("button");
      if (btn) btn.click();
    }
  });
});

function unlockDashboard() {
  $("#authGate").classList.add("hidden");
  $("#dashboard").classList.remove("hidden");
  loadAllLists();
  loadProtectionToggle();
  loadTimeLimits();
  loadBlockPageConfig();
  scheduleAutoLock();
}

// ---------------------------------------------------------------------------
// Auto-lock — the dashboard re-locks itself after 1 minute of inactivity, so
// it isn't left open and unattended. Any click, keystroke, or scroll while
// it's open resets the countdown; the timer only runs while the dashboard
// is actually visible.
// ---------------------------------------------------------------------------

const AUTO_LOCK_MS = 60 * 1000;
let autoLockTimer = null;

function isDashboardUnlocked() {
  return !$("#dashboard").classList.contains("hidden");
}

function scheduleAutoLock() {
  if (!isDashboardUnlocked()) return;
  clearTimeout(autoLockTimer);
  autoLockTimer = setTimeout(lockDashboard, AUTO_LOCK_MS);
}

function lockDashboard() {
  clearTimeout(autoLockTimer);
  autoLockTimer = null;
  if (!isDashboardUnlocked()) return;

  $("#dashboard").classList.add("hidden");
  $("#authGate").classList.remove("hidden");
  $("#setupForm").classList.add("hidden");
  $("#loginForm").classList.remove("hidden");

  // Clear anything sensitive left sitting in input fields.
  $("#loginPassword").value = "";
  $("#oldPassword").value = "";
  $("#changeNewPassword").value = "";
  $("#changeNewPassword2").value = "";
  $("#authError").textContent = "";

  $("#loginPassword").focus();
}

["mousedown", "mousemove", "keydown", "scroll", "input", "wheel", "touchstart"].forEach(evt => {
  document.addEventListener(evt, scheduleAutoLock, { passive: true });
});

// Re-arm when the tab regains focus/visibility, in case time passed while
// it was backgrounded (setTimeout can lag in an inactive tab).
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") scheduleAutoLock();
});

// ---------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------

$all(".tab-btn[data-tab]").forEach(btn => {
  btn.addEventListener("click", () => {
    $all(".tab-btn").forEach(b => b.classList.remove("active"));
    $all(".tab").forEach(t => t.classList.remove("active"));
    btn.classList.add("active");
    $(`#tab-${btn.dataset.tab}`).classList.add("active");
  });
});

// ---------------------------------------------------------------------------
// Protection toggle
// ---------------------------------------------------------------------------

async function loadProtectionToggle() {
  const { protectionEnabled = true } = await chrome.storage.local.get("protectionEnabled");
  $("#protectionToggle").checked = protectionEnabled;
}

$("#protectionToggle").addEventListener("change", async e => {
  await chrome.storage.local.set({ protectionEnabled: e.target.checked });
});

// ---------------------------------------------------------------------------
// List management (sites, URL keywords, content keywords)
// ---------------------------------------------------------------------------

const LIST_CONFIG = {
  sites: { storageKey: "blockedSites", listEl: "#siteList", inputEl: "#siteInput", lower: true },
  urlkw: { storageKey: "urlKeywords", listEl: "#urlKwList", inputEl: "#urlKwInput", lower: true },
  contentkw: { storageKey: "contentKeywords", listEl: "#contentKwList", inputEl: "#contentKwInput", lower: false }
};

async function loadAllLists() {
  for (const key of Object.keys(LIST_CONFIG)) await renderList(key);
}

async function renderList(key) {
  const cfg = LIST_CONFIG[key];
  const data = await chrome.storage.local.get(cfg.storageKey);
  const items = data[cfg.storageKey] || [];
  const ul = $(cfg.listEl);
  ul.innerHTML = "";

  if (items.length === 0) {
    const li = document.createElement("li");
    li.className = "ledger-empty";
    li.textContent = "Nothing added yet.";
    ul.appendChild(li);
    return;
  }

  items.forEach((item, idx) => {
    const li = document.createElement("li");
    li.className = "ledger-row";

    const span = document.createElement("span");
    span.className = "ledger-value";
    span.textContent = item;

    const removeBtn = document.createElement("button");
    removeBtn.className = "remove-btn";
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", async () => {
      const fresh = (await chrome.storage.local.get(cfg.storageKey))[cfg.storageKey] || [];
      fresh.splice(idx, 1);
      await chrome.storage.local.set({ [cfg.storageKey]: fresh });
      renderList(key);
    });

    li.appendChild(span);
    li.appendChild(removeBtn);
    ul.appendChild(li);
  });
}

async function addItem(key) {
  const cfg = LIST_CONFIG[key];
  const input = $(cfg.inputEl);
  const value = input.value.trim();
  if (!value) return;
  const data = await chrome.storage.local.get(cfg.storageKey);
  const items = data[cfg.storageKey] || [];
  const normalized = cfg.lower ? value.toLowerCase() : value;
  if (!items.includes(normalized)) items.push(normalized);
  await chrome.storage.local.set({ [cfg.storageKey]: items });
  input.value = "";
  input.focus();
  renderList(key);
}

$("#addSiteBtn").addEventListener("click", () => addItem("sites"));
$("#addUrlKwBtn").addEventListener("click", () => addItem("urlkw"));
$("#addContentKwBtn").addEventListener("click", () => addItem("contentkw"));

$("#siteInput").addEventListener("keydown", e => { if (e.key === "Enter") addItem("sites"); });
$("#urlKwInput").addEventListener("keydown", e => { if (e.key === "Enter") addItem("urlkw"); });
$("#contentKwInput").addEventListener("keydown", e => { if (e.key === "Enter") addItem("contentkw"); });

// ---------------------------------------------------------------------------
// Time limits
// ---------------------------------------------------------------------------

// Reads a usage entry as seconds, tolerating the older {minutesUsed} format.
function usedSecondsFor(entry, todayStr) {
  if (!entry || entry.date !== todayStr) return 0;
  if (typeof entry.secondsUsed === "number") return entry.secondsUsed;
  if (typeof entry.minutesUsed === "number") return entry.minutesUsed * 60;
  return 0;
}

function formatUsed(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  if (mins === 0) return `${secs}s`;
  return `${mins}m ${String(secs).padStart(2, "0")}s`;
}

async function loadTimeLimits() {
  const { timeLimits = {}, timeUsage = {} } = await chrome.storage.local.get(["timeLimits", "timeUsage"]);
  const ul = $("#timeLimitList");
  ul.innerHTML = "";

  const domains = Object.keys(timeLimits);
  if (domains.length === 0) {
    const li = document.createElement("li");
    li.className = "ledger-empty";
    li.textContent = "No time limits set.";
    ul.appendChild(li);
    return;
  }

  const todayStr = todayDateStr();

  domains.sort().forEach(domain => {
    const limit = timeLimits[domain];
    const usedSeconds = usedSecondsFor(timeUsage[domain], todayStr);
    const pct = Math.min(100, Math.round((usedSeconds / (limit * 60)) * 100));

    const li = document.createElement("li");
    li.className = "ledger-row time-row";

    const info = document.createElement("div");
    info.className = "tl-info";

    const nameRow = document.createElement("div");
    nameRow.className = "tl-name-row";
    const name = document.createElement("span");
    name.className = "ledger-value";
    name.textContent = domain;
    const usageLabel = document.createElement("span");
    usageLabel.className = "tl-usage";
    usageLabel.textContent = `${formatUsed(usedSeconds)} of ${limit} min today`;
    nameRow.appendChild(name);
    nameRow.appendChild(usageLabel);

    const bar = document.createElement("div");
    bar.className = "tl-bar";
    const fill = document.createElement("div");
    fill.className = "tl-bar-fill";
    fill.style.width = `${pct}%`;
    if (pct >= 100) fill.classList.add("full");
    bar.appendChild(fill);

    info.appendChild(nameRow);
    info.appendChild(bar);

    const actions = document.createElement("div");
    actions.className = "ledger-actions";

    const resetBtn = document.createElement("button");
    resetBtn.className = "secondary-btn";
    resetBtn.textContent = "Reset today";
    resetBtn.addEventListener("click", async () => {
      const { timeUsage: fresh = {} } = await chrome.storage.local.get("timeUsage");
      fresh[domain] = { date: todayDateStr(), secondsUsed: 0, lastBeat: 0 };
      await chrome.storage.local.set({ timeUsage: fresh });
      loadTimeLimits();
    });

    const removeBtn = document.createElement("button");
    removeBtn.className = "remove-btn";
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", async () => {
      const { timeLimits: freshLimits = {}, timeUsage: freshUsage = {} } =
        await chrome.storage.local.get(["timeLimits", "timeUsage"]);
      delete freshLimits[domain];
      delete freshUsage[domain];
      await chrome.storage.local.set({ timeLimits: freshLimits, timeUsage: freshUsage });
      loadTimeLimits();
    });

    actions.appendChild(resetBtn);
    actions.appendChild(removeBtn);

    li.appendChild(info);
    li.appendChild(actions);
    ul.appendChild(li);
  });
}

$("#addTimeLimitBtn").addEventListener("click", async () => {
  const domainInput = $("#timeLimitDomainInput");
  const minutesInput = $("#timeLimitMinutesInput");
  const domain = normalizeDomain(domainInput.value);
  const minutes = parseInt(minutesInput.value, 10);
  if (!domain || !minutes || minutes < 1) return;

  const { timeLimits = {} } = await chrome.storage.local.get("timeLimits");
  timeLimits[domain] = minutes;
  await chrome.storage.local.set({ timeLimits });
  domainInput.value = "";
  minutesInput.value = "";
  domainInput.focus();
  loadTimeLimits();
});

// Keep the "used today" figures live while the dashboard is open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (!$("#dashboard").classList.contains("hidden")) {
    if (changes.timeUsage || changes.timeLimits) loadTimeLimits();
  }
});

// ---------------------------------------------------------------------------
// Block page editor
// ---------------------------------------------------------------------------

const DEFAULT_BLOCK_PAGE = {
  heading: "This page has been stopped",
  stamp: "BLOCKED",
  message: ""
};

async function loadBlockPageConfig() {
  const { blockPageConfig = {} } = await chrome.storage.local.get("blockPageConfig");
  const cfg = { ...DEFAULT_BLOCK_PAGE, ...blockPageConfig };
  $("#bpHeading").value = cfg.heading;
  $("#bpStamp").value = cfg.stamp;
  $("#bpMessage").value = cfg.message;
  updateBlockPagePreview();
}

function updateBlockPagePreview() {
  const heading = $("#bpHeading").value.trim() || DEFAULT_BLOCK_PAGE.heading;
  const stamp = ($("#bpStamp").value.trim() || DEFAULT_BLOCK_PAGE.stamp).toUpperCase();
  const message = $("#bpMessage").value.trim();

  $("#previewHeading").textContent = heading;
  $("#previewStamp").textContent = stamp;
  const msgEl = $("#previewMessage");
  msgEl.textContent = message;
  msgEl.style.display = message ? "block" : "none";
}

$all("#bpHeading, #bpStamp, #bpMessage").forEach(el => {
  el.addEventListener("input", updateBlockPagePreview);
});

$("#saveBlockPageBtn").addEventListener("click", async () => {
  const blockPageConfig = {
    heading: $("#bpHeading").value.trim() || DEFAULT_BLOCK_PAGE.heading,
    stamp: $("#bpStamp").value.trim() || DEFAULT_BLOCK_PAGE.stamp,
    message: $("#bpMessage").value.trim()
  };
  await chrome.storage.local.set({ blockPageConfig });
  const ok = $("#blockPageSaved");
  ok.textContent = "Saved.";
  setTimeout(() => { ok.textContent = ""; }, 2000);
});

// ---------------------------------------------------------------------------
// Security tab — temporary unlock (the only way to unlock a blocked page,
// and it lives here, behind the dashboard password) + change password
// ---------------------------------------------------------------------------

$("#unlockDomainBtn").addEventListener("click", async () => {
  const domainInput = $("#unlockDomainInput");
  const domain = normalizeDomain(domainInput.value);
  const minutes = parseInt($("#unlockDomainMinutes").value, 10);
  const ok = $("#unlockSuccess");
  ok.textContent = "";
  if (!domain) return;

  const { tempUnlocks = {} } = await chrome.storage.local.get("tempUnlocks");
  tempUnlocks[domain] = Date.now() + minutes * 60000;
  await chrome.storage.local.set({ tempUnlocks });
  chrome.alarms.create(`reblock:${domain}`, { delayInMinutes: minutes });

  ok.textContent = `"${domain}" unlocked for ${minutes} minutes.`;
  domainInput.value = "";
});

$("#changePasswordBtn").addEventListener("click", async () => {
  const oldPassword = $("#oldPassword").value;
  const newPassword = $("#changeNewPassword").value;
  const newPassword2 = $("#changeNewPassword2").value;
  const err = $("#changeError");
  const ok = $("#changeSuccess");
  err.textContent = "";
  ok.textContent = "";

  if (newPassword !== newPassword2) {
    err.textContent = "New passwords do not match.";
    return;
  }

  const resp = await sendMsg({ type: "AUTH_CHANGE", oldPassword, newPassword });
  if (resp.ok) {
    ok.textContent = "Password updated.";
    $("#oldPassword").value = "";
    $("#changeNewPassword").value = "";
    $("#changeNewPassword2").value = "";
  } else {
    err.textContent = resp.error || "Could not change password.";
  }
});

initAuth();
