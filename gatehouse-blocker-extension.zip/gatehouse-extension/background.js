// background.js
// Everything here runs locally inside the browser. No network requests are
// ever made by this extension — settings, keywords, usage counters, and the
// password hash all live in chrome.storage.local on this machine only.

// ---------------------------------------------------------------------------
// Password hashing (PBKDF2-SHA256, salted). We never store the plaintext
// password — only a salt and the derived hash. This is used ONLY by the
// dashboard (options.js) to gate entry to the dashboard itself. Nothing on
// the blocked page ever touches a password.
// ---------------------------------------------------------------------------

function bytesToHex(bytes) {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
}

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return bytes;
}

function randomSaltHex() {
  return bytesToHex(crypto.getRandomValues(new Uint8Array(16)));
}

async function hashPassword(password, saltHex) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: hexToBytes(saltHex), iterations: 100000, hash: "SHA-256" },
    keyMaterial,
    256
  );
  return bytesToHex(new Uint8Array(bits));
}

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function normalizeDomain(raw) {
  if (!raw) return "";
  let d = raw.trim().toLowerCase();
  d = d.replace(/^https?:\/\//, "");
  d = d.split("/")[0];
  d = d.replace(/^www\./, "");
  return d;
}

function todayDateStr() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function findLimitedDomain(hostname, timeLimits) {
  const host = (hostname || "").toLowerCase().replace(/^www\./, "");
  if (Object.prototype.hasOwnProperty.call(timeLimits, host)) return host;
  for (const key of Object.keys(timeLimits)) {
    if (host.endsWith("." + key)) return key;
  }
  return null;
}

// Read a usage entry as seconds, tolerating the older {minutesUsed} format.
function usedSecondsFor(entry, todayStr) {
  if (!entry || entry.date !== todayStr) return 0;
  if (typeof entry.secondsUsed === "number") return entry.secondsUsed;
  if (typeof entry.minutesUsed === "number") return entry.minutesUsed * 60;
  return 0;
}

function isUnlocked(domain, tempUnlocks) {
  return !!(tempUnlocks && tempUnlocks[domain] && tempUnlocks[domain] > Date.now());
}

// Actively push any tab already sitting on `domain` over to the blocked page.
// declarativeNetRequest only stops *new* navigations, so without this a tab
// opened before the block took effect would sit there until manually
// reloaded. The content script enforces this too — this is the belt to its
// braces, for pages where the content script may not be running.
async function redirectOpenTabs(domain, query) {
  const blockedPageUrl = chrome.runtime.getURL("blocked.html");
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: [`*://${domain}/*`, `*://*.${domain}/*`] });
  } catch (e) {
    return;
  }
  const target = `${blockedPageUrl}?${query}`;
  for (const tab of tabs) {
    if (!tab.id || !tab.url) continue;
    if (tab.url.startsWith(blockedPageUrl)) continue;
    try {
      await chrome.tabs.update(tab.id, { url: target });
    } catch (e) {
      /* tab may have closed mid-sweep */
    }
  }
}

// ---------------------------------------------------------------------------
// Blocking rules (declarativeNetRequest) + sweep of already-open tabs
// ---------------------------------------------------------------------------

async function updateRules(options = {}) {
  const { sweepTabs = true } = options;

  const {
    protectionEnabled = true,
    blockedSites = [],
    urlKeywords = [],
    tempUnlocks = {},
    timeLimits = {},
    timeUsage = {}
  } = await chrome.storage.local.get([
    "protectionEnabled",
    "blockedSites",
    "urlKeywords",
    "tempUnlocks",
    "timeLimits",
    "timeUsage"
  ]);

  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const existingIds = existing.map(r => r.id);

  if (!protectionEnabled) {
    if (existingIds.length) {
      await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existingIds });
    }
    return;
  }

  const now = Date.now();
  const unlockedDomains = Object.entries(tempUnlocks)
    .filter(([, expiry]) => expiry > now)
    .map(([domain]) => domain);
  const unlockedSet = new Set(unlockedDomains);

  const blockedPageUrl = chrome.runtime.getURL("blocked.html");
  const rules = [];
  const activeEnforcements = [];
  let id = 1;

  // 1) Explicit blocked sites
  for (const raw of blockedSites) {
    const domain = normalizeDomain(raw);
    if (!domain || unlockedSet.has(domain)) continue;
    const query = `reason=site&site=${encodeURIComponent(domain)}`;
    rules.push({
      id: id++,
      priority: 1,
      action: { type: "redirect", redirect: { url: `${blockedPageUrl}?${query}` } },
      condition: { urlFilter: `||${domain}^`, resourceTypes: ["main_frame"] }
    });
    activeEnforcements.push({ domain, query });
  }

  // 2) URL keywords (not domain-scoped, so no open-tab sweep for these)
  for (const raw of urlKeywords) {
    const kw = (raw || "").trim().toLowerCase();
    if (!kw) continue;
    const condition = {
      urlFilter: kw,
      isUrlFilterCaseSensitive: false,
      resourceTypes: ["main_frame"]
    };
    if (unlockedDomains.length) condition.excludedRequestDomains = unlockedDomains;
    rules.push({
      id: id++,
      priority: 1,
      action: {
        type: "redirect",
        redirect: { url: `${blockedPageUrl}?reason=urlkeyword&kw=${encodeURIComponent(kw)}` }
      },
      condition
    });
  }

  // 3) Sites that have used up today's time budget
  const todayStr = todayDateStr();
  for (const [domain, limitMinutes] of Object.entries(timeLimits)) {
    if (!domain || unlockedSet.has(domain)) continue;
    const usedSeconds = usedSecondsFor(timeUsage[domain], todayStr);
    if (usedSeconds >= limitMinutes * 60) {
      const query = `reason=timelimit&site=${encodeURIComponent(domain)}`;
      rules.push({
        id: id++,
        priority: 1,
        action: { type: "redirect", redirect: { url: `${blockedPageUrl}?${query}` } },
        condition: { urlFilter: `||${domain}^`, resourceTypes: ["main_frame"] }
      });
      activeEnforcements.push({ domain, query });
    }
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: existingIds,
    addRules: rules
  });

  if (sweepTabs) {
    for (const { domain, query } of activeEnforcements) {
      await redirectOpenTabs(domain, query);
    }
  }
}

// ---------------------------------------------------------------------------
// Screen-time accounting
// ---------------------------------------------------------------------------
// The content script on a limited page sends a heartbeat every few seconds
// while that page is genuinely visible and focused. We add the REAL elapsed
// wall-clock time between heartbeats (capped, so a suspended tab or a
// sleeping laptop can't dump a huge chunk in at once) rather than counting
// alarm ticks — which was unreliable, because MV3 service workers wake and
// restart at unpredictable times.

// Make sure a redirect rule for this expired domain is actually installed.
// Idempotent: if the rule is already present it does nothing, so this can be
// called on every heartbeat without churning the ruleset.
async function ensureTimeLimitRule(domain, limitMinutes, alreadyKnownOver) {
  const query = `reason=timelimit&site=${encodeURIComponent(domain)}`;
  try {
    const rules = await chrome.declarativeNetRequest.getDynamicRules();
    const already = rules.some(
      r =>
        r.condition &&
        r.condition.urlFilter === `||${domain}^` &&
        r.action &&
        r.action.redirect &&
        r.action.redirect.url &&
        r.action.redirect.url.includes("reason=timelimit")
    );
    if (already) return;
  } catch (e) {
    /* fall through and rebuild */
  }
  await updateRules();
  if (!alreadyKnownOver) await redirectOpenTabs(domain, query);
}

// Decide whether a URL should be blocked right now, and why.
async function evaluateUrl(url) {
  if (!url || !/^https?:/i.test(url)) return null;

  let hostname;
  try {
    hostname = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  } catch (e) {
    return null;
  }
  if (!hostname) return null;

  const {
    protectionEnabled = true,
    blockedSites = [],
    tempUnlocks = {},
    timeLimits = {},
    timeUsage = {}
  } = await chrome.storage.local.get([
    "protectionEnabled",
    "blockedSites",
    "tempUnlocks",
    "timeLimits",
    "timeUsage"
  ]);

  if (!protectionEnabled) return null;

  const matches = d => hostname === d || hostname.endsWith("." + d);

  const site = blockedSites.map(normalizeDomain).find(d => d && matches(d));
  if (site && !isUnlocked(site, tempUnlocks)) {
    return `reason=site&site=${encodeURIComponent(site)}`;
  }

  const limited = findLimitedDomain(hostname, timeLimits);
  if (limited && !isUnlocked(limited, tempUnlocks)) {
    const todayStr = todayDateStr();
    const usedSeconds = usedSecondsFor(timeUsage[limited], todayStr);
    if (usedSeconds >= timeLimits[limited] * 60) {
      return `reason=timelimit&site=${encodeURIComponent(limited)}`;
    }
  }

  return null;
}

// Independent enforcement layer: catch navigations as they happen, so the
// whole site stays blocked even if a declarativeNetRequest rule is missing
// or the content script can't run on a given page.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const url = changeInfo.url || (changeInfo.status === "loading" ? tab && tab.url : null);
  if (!url) return;
  const blockedPageUrl = chrome.runtime.getURL("blocked.html");
  if (url.startsWith(blockedPageUrl)) return;

  const query = await evaluateUrl(url);
  if (!query) return;
  try {
    await chrome.tabs.update(tabId, { url: `${blockedPageUrl}?${query}` });
  } catch (e) {
    /* tab closed or navigated away */
  }
});

const HEARTBEAT_INTERVAL_MS = 5000;
const MAX_HEARTBEAT_DELTA_MS = 10000;

async function handleHeartbeat(msg) {
  const { protectionEnabled = true, timeLimits = {}, tempUnlocks = {} } =
    await chrome.storage.local.get(["protectionEnabled", "timeLimits", "tempUnlocks"]);

  const domain = normalizeDomain(msg.domain || "");
  const limitMinutes = timeLimits[domain];

  if (!domain || !limitMinutes) return { tracked: false };
  if (!protectionEnabled) return { tracked: false };
  if (isUnlocked(domain, tempUnlocks)) {
    return { tracked: true, paused: true, remainingSeconds: null, limitMinutes };
  }

  const { timeUsage = {} } = await chrome.storage.local.get("timeUsage");
  const todayStr = todayDateStr();
  const prev = timeUsage[domain];
  const carried = usedSecondsFor(prev, todayStr);
  const entry = {
    date: todayStr,
    secondsUsed: carried,
    lastBeat: prev && prev.date === todayStr ? prev.lastBeat || 0 : 0
  };

  const now = Date.now();
  if (msg.active) {
    const rawDelta = entry.lastBeat ? now - entry.lastBeat : HEARTBEAT_INTERVAL_MS;
    const delta = Math.min(Math.max(rawDelta, 0), MAX_HEARTBEAT_DELTA_MS);
    entry.secondsUsed = carried + delta / 1000;
  }
  entry.lastBeat = now;

  const limitSeconds = limitMinutes * 60;
  const wasOver = carried >= limitSeconds;
  const isOver = entry.secondsUsed >= limitSeconds;

  timeUsage[domain] = entry;
  await chrome.storage.local.set({ timeUsage });

  // Rebuild the blocking rules whenever the budget is spent — not only on
  // the single tick where it first crosses. Relying on that one moment was
  // fragile: if the service worker happened to be asleep or restarting then,
  // the rule was never added and the rest of the site stayed reachable.
  // ensureTimeLimitRule() is cheap and idempotent, so running it on each
  // over-limit heartbeat is fine.
  if (isOver) {
    await ensureTimeLimitRule(domain, limitMinutes, wasOver);
  }

  return {
    tracked: true,
    paused: false,
    limitMinutes,
    remainingSeconds: Math.max(0, Math.round(limitSeconds - entry.secondsUsed)),
    blocked: isOver
  };
}

function scheduleMidnightAlarm() {
  const now = new Date();
  const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 1, 0);
  const delayMinutes = Math.max(1, Math.round((next.getTime() - now.getTime()) / 60000));
  chrome.alarms.create("gatehouse-midnight-reset", {
    delayInMinutes: delayMinutes,
    periodInMinutes: 1440
  });
}

function ensureAlarms() {
  // Periodic safety net: re-derives rules in case anything drifted.
  chrome.alarms.create("gatehouse-recheck", { periodInMinutes: 1 });
  scheduleMidnightAlarm();
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async () => {
  const defaults = {
    protectionEnabled: true,
    blockedSites: [],
    urlKeywords: [],
    contentKeywords: [],
    tempUnlocks: {},
    timeLimits: {},
    timeUsage: {},
    blockPageConfig: {
      heading: "This page has been stopped",
      stamp: "BLOCKED",
      message: ""
    }
  };
  const existing = await chrome.storage.local.get(Object.keys(defaults));
  const toSet = {};
  for (const key of Object.keys(defaults)) {
    if (existing[key] === undefined) toSet[key] = defaults[key];
  }
  if (Object.keys(toSet).length) await chrome.storage.local.set(toSet);
  ensureAlarms();
  await updateRules();
});

chrome.runtime.onStartup.addListener(() => {
  ensureAlarms();
  updateRules();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  // timeUsage deliberately excluded: it changes every few seconds, and the
  // heartbeat handler already rebuilds rules at the moment a budget expires.
  const relevantKeys = [
    "protectionEnabled",
    "blockedSites",
    "urlKeywords",
    "tempUnlocks",
    "timeLimits"
  ];
  if (Object.keys(changes).some(k => relevantKeys.includes(k))) {
    updateRules();
  }
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name.startsWith("reblock:")) {
    const domain = alarm.name.slice("reblock:".length);
    const { tempUnlocks = {} } = await chrome.storage.local.get("tempUnlocks");
    delete tempUnlocks[domain];
    await chrome.storage.local.set({ tempUnlocks });
    await updateRules();
    return;
  }
  if (alarm.name === "gatehouse-recheck") {
    await updateRules();
    return;
  }
  if (alarm.name === "gatehouse-midnight-reset") {
    await updateRules();
    return;
  }
});

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "TIME_HEARTBEAT": {
        sendResponse(await handleHeartbeat(msg));
        break;
      }

      case "AUTH_STATUS": {
        const { authHash } = await chrome.storage.local.get("authHash");
        sendResponse({ hasPassword: !!authHash });
        break;
      }

      case "AUTH_SETUP": {
        const { authHash } = await chrome.storage.local.get("authHash");
        if (authHash) {
          sendResponse({ ok: false, error: "A password is already set." });
          break;
        }
        if (!msg.password || msg.password.length < 4) {
          sendResponse({ ok: false, error: "Password must be at least 4 characters." });
          break;
        }
        const salt = randomSaltHex();
        const hash = await hashPassword(msg.password, salt);
        await chrome.storage.local.set({ authSalt: salt, authHash: hash });
        sendResponse({ ok: true });
        break;
      }

      case "AUTH_VERIFY": {
        const { authSalt, authHash } = await chrome.storage.local.get(["authSalt", "authHash"]);
        if (!authSalt || !authHash) {
          sendResponse({ ok: false, error: "No password has been set yet." });
          break;
        }
        const hash = await hashPassword(msg.password || "", authSalt);
        sendResponse({ ok: hash === authHash });
        break;
      }

      case "AUTH_CHANGE": {
        const { authSalt, authHash } = await chrome.storage.local.get(["authSalt", "authHash"]);
        if (!authSalt || !authHash) {
          sendResponse({ ok: false, error: "No password has been set yet." });
          break;
        }
        const oldHash = await hashPassword(msg.oldPassword || "", authSalt);
        if (oldHash !== authHash) {
          sendResponse({ ok: false, error: "Current password is incorrect." });
          break;
        }
        if (!msg.newPassword || msg.newPassword.length < 4) {
          sendResponse({ ok: false, error: "New password must be at least 4 characters." });
          break;
        }
        const newSalt = randomSaltHex();
        const newHash = await hashPassword(msg.newPassword, newSalt);
        await chrome.storage.local.set({ authSalt: newSalt, authHash: newHash });
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({ ok: false, error: "Unknown message type." });
    }
  })();
  return true; // keep the message channel open for the async response
});
