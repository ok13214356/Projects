// content.js
// 1) Scans this page's visible text for blocked keywords.
// 2) Self-enforces blocks on an already-open page, so a site that becomes
//    blocked while you're sitting on it redirects immediately, with no reload.
// 3) If this domain has a daily time limit, shows a small floating,
//    see-through, draggable, closable widget with the time left.
// Everything it reads comes from local extension storage — nothing is sent
// anywhere.

(function () {
  const HIDE_STYLE_ID = "__gatehouse_hide__";
  const HEARTBEAT_MS = 5000;

  let redirecting = false;

  function hidePage() {
    if (document.getElementById(HIDE_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = HIDE_STYLE_ID;
    style.textContent = "html{visibility:hidden !important}";
    (document.head || document.documentElement).appendChild(style);
  }

  function showPage() {
    const style = document.getElementById(HIDE_STYLE_ID);
    if (style) style.remove();
  }

  function redirectToBlocked(reason, extra) {
    if (redirecting) return;
    redirecting = true;
    const blockedUrl = chrome.runtime.getURL("blocked.html");
    const params = new URLSearchParams({ reason, url: location.href, ...extra });
    location.replace(`${blockedUrl}?${params.toString()}`);
  }

  function normalizeDomain(raw) {
    if (!raw) return "";
    let d = String(raw).trim().toLowerCase();
    d = d.replace(/^https?:\/\//, "");
    d = d.split("/")[0];
    d = d.replace(/^www\./, "");
    return d;
  }

  function findLimitedDomain(hostname, timeLimits) {
    const host = (hostname || "").toLowerCase().replace(/^www\./, "");
    if (Object.prototype.hasOwnProperty.call(timeLimits, host)) return host;
    for (const key of Object.keys(timeLimits)) {
      if (host.endsWith("." + key)) return key;
    }
    return null;
  }

  function todayDateStr() {
    const d = new Date();
    const pad = n => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  // Reads a usage entry as seconds, tolerating the older {minutesUsed} format.
  function usedSecondsFor(entry, todayStr) {
    if (!entry || entry.date !== todayStr) return 0;
    if (typeof entry.secondsUsed === "number") return entry.secondsUsed;
    if (typeof entry.minutesUsed === "number") return entry.minutesUsed * 60;
    return 0;
  }

  const currentHost = location.hostname.toLowerCase().replace(/^www\./, "");

  function hostMatches(domain) {
    return currentHost === domain || currentHost.endsWith("." + domain);
  }

  // -------------------------------------------------------------------
  // Self-enforcement: if this page's domain is added to the blocked list
  // (or its temporary unlock expires) while the page is already open,
  // redirect right away rather than waiting for a reload.
  // -------------------------------------------------------------------

  function watchForBlockListChanges() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (!(changes.blockedSites || changes.tempUnlocks || changes.protectionEnabled)) return;

      chrome.storage.local.get(
        ["protectionEnabled", "blockedSites", "tempUnlocks"],
        data => {
          if (data.protectionEnabled === false) return;
          const tempUnlocks = data.tempUnlocks || {};
          const match = (data.blockedSites || [])
            .map(normalizeDomain)
            .find(d => d && hostMatches(d));
          if (!match) return;
          if (tempUnlocks[match] && tempUnlocks[match] > Date.now()) return;
          redirectToBlocked("site", { site: match });
        }
      );
    });
  }

  // -------------------------------------------------------------------
  // Floating time-left widget: see-through, draggable, closable.
  // The countdown is driven by heartbeat replies from the background
  // script, which tracks real elapsed time — the local per-second tick is
  // only smoothing between replies, and is corrected on every heartbeat.
  // -------------------------------------------------------------------

  function initTimeTracking(domain, limitMinutes) {
    if (document.getElementById("gatehouse-widget-host")) return;

    let widgetClosed = false;
    let remainingSeconds = limitMinutes * 60;
    let paused = false;

    const host = document.createElement("div");
    host.id = "gatehouse-widget-host";
    host.style.all = "initial";
    host.style.position = "fixed";
    host.style.zIndex = "2147483647";
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        .gh-widget {
          position: fixed;
          right: 18px;
          bottom: 18px;
          width: 176px;
          font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
          background: rgba(28, 35, 33, 0.62);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          color: #f7f8f4;
          border: 1px solid rgba(255, 255, 255, 0.16);
          border-radius: 8px;
          box-shadow: 0 6px 18px rgba(0, 0, 0, 0.22);
          overflow: hidden;
          user-select: none;
        }
        .gh-header {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 7px 8px;
          cursor: grab;
          background: rgba(255, 255, 255, 0.06);
        }
        .gh-header:active { cursor: grabbing; }
        .gh-dot {
          width: 6px; height: 6px; border-radius: 50%;
          background: #7fd6c4; flex-shrink: 0;
        }
        .gh-dot.low { background: #e0897a; }
        .gh-title { font-size: 11px; letter-spacing: 0.3px; opacity: 0.8; flex: 1; }
        .gh-close {
          all: initial; font-family: inherit; cursor: pointer;
          color: #f7f8f4; opacity: 0.6; font-size: 13px; line-height: 1; padding: 2px 4px;
        }
        .gh-close:hover { opacity: 1; }
        .gh-body { padding: 9px 10px 11px; }
        .gh-domain {
          font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
          font-size: 10.5px; opacity: 0.7; margin-bottom: 4px;
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .gh-time {
          font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
          font-size: 17px; font-weight: 600;
        }
        .gh-time.done { color: #e0897a; font-size: 13px; font-weight: 500; }
        .gh-sub { font-size: 10px; opacity: 0.65; margin-top: 2px; }
      </style>
      <div class="gh-widget" id="ghWidget">
        <div class="gh-header" id="ghHeader">
          <span class="gh-dot" id="ghDot"></span>
          <span class="gh-title">Gatehouse</span>
          <button class="gh-close" id="ghClose" title="Close">&times;</button>
        </div>
        <div class="gh-body">
          <div class="gh-domain" id="ghDomain"></div>
          <div class="gh-time" id="ghTime">--:--</div>
          <div class="gh-sub" id="ghSub">left today</div>
        </div>
      </div>
    `;

    const widget = shadow.getElementById("ghWidget");
    const header = shadow.getElementById("ghHeader");
    const closeBtn = shadow.getElementById("ghClose");
    const domainEl = shadow.getElementById("ghDomain");
    const timeEl = shadow.getElementById("ghTime");
    const subEl = shadow.getElementById("ghSub");
    const dotEl = shadow.getElementById("ghDot");

    domainEl.textContent = domain;

    chrome.storage.local.get("widgetPosition", ({ widgetPosition }) => {
      if (widgetPosition && typeof widgetPosition.left === "number") {
        widget.style.left = `${widgetPosition.left}px`;
        widget.style.top = `${widgetPosition.top}px`;
        widget.style.right = "auto";
        widget.style.bottom = "auto";
      }
    });

    function render() {
      if (widgetClosed) return;
      if (paused) {
        timeEl.textContent = "Unlocked";
        timeEl.classList.remove("done");
        subEl.textContent = "limit paused";
        dotEl.classList.remove("low");
        return;
      }
      if (remainingSeconds <= 0) {
        timeEl.textContent = "Time's up";
        timeEl.classList.add("done");
        subEl.textContent = "unlocks at midnight";
        dotEl.classList.add("low");
        return;
      }
      const mm = Math.floor(remainingSeconds / 60);
      const ss = Math.floor(remainingSeconds % 60);
      timeEl.textContent = `${mm}:${String(ss).padStart(2, "0")}`;
      timeEl.classList.remove("done");
      subEl.textContent = "left today";
      dotEl.classList.toggle("low", remainingSeconds <= 120);
    }

    function isPageActive() {
      return document.visibilityState === "visible" && document.hasFocus();
    }

    async function beat() {
      if (redirecting) return;
      let resp;
      try {
        resp = await chrome.runtime.sendMessage({
          type: "TIME_HEARTBEAT",
          domain,
          active: isPageActive()
        });
      } catch (e) {
        return; // service worker restarting; try again next beat
      }
      if (!resp || !resp.tracked) return;

      paused = !!resp.paused;
      if (!paused && typeof resp.remainingSeconds === "number") {
        remainingSeconds = resp.remainingSeconds;
      }
      render();

      if (resp.blocked) {
        redirectToBlocked("timelimit", { site: domain });
      }
    }

    // Local smoothing between heartbeats, corrected by every reply above.
    const tickTimer = setInterval(() => {
      if (paused || redirecting) return;
      if (remainingSeconds > 0 && isPageActive()) {
        remainingSeconds -= 1;
        render();
      }
    }, 1000);

    const beatTimer = setInterval(beat, HEARTBEAT_MS);
    beat();

    // Beat immediately on focus/visibility changes so the count picks up
    // and resumes promptly rather than waiting out the interval.
    document.addEventListener("visibilitychange", beat);
    window.addEventListener("focus", beat);
    window.addEventListener("blur", beat);

    // Drag to move.
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    header.addEventListener("mousedown", e => {
      if (e.target === closeBtn) return;
      dragging = true;
      const rect = widget.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      e.preventDefault();
    });

    function onMove(e) {
      if (!dragging) return;
      const maxLeft = window.innerWidth - widget.offsetWidth - 4;
      const maxTop = window.innerHeight - widget.offsetHeight - 4;
      const left = Math.min(Math.max(4, e.clientX - offsetX), Math.max(4, maxLeft));
      const top = Math.min(Math.max(4, e.clientY - offsetY), Math.max(4, maxTop));
      widget.style.left = `${left}px`;
      widget.style.top = `${top}px`;
      widget.style.right = "auto";
      widget.style.bottom = "auto";
    }

    function onUp() {
      if (!dragging) return;
      dragging = false;
      const rect = widget.getBoundingClientRect();
      chrome.storage.local.set({ widgetPosition: { left: rect.left, top: rect.top } });
    }

    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);

    // Closing hides the widget only — tracking and blocking continue.
    closeBtn.addEventListener("click", e => {
      e.stopPropagation();
      widgetClosed = true;
      clearInterval(tickTimer);
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
      host.remove();
    });
  }

  // Returns true if it redirected. Checked on every page load, so a site
  // whose budget is already spent is stopped straight away rather than
  // waiting on the first heartbeat reply or a network-level rule.
  function maybeInitTimeTracking(data) {
    if (data.protectionEnabled === false) return false;
    const timeLimits = data.timeLimits || {};
    if (Object.keys(timeLimits).length === 0) return false;

    const domain = findLimitedDomain(currentHost, timeLimits);
    if (!domain) return false;

    const tempUnlocks = data.tempUnlocks || {};
    if (tempUnlocks[domain] && tempUnlocks[domain] > Date.now()) return false;

    const usedSeconds = usedSecondsFor((data.timeUsage || {})[domain], todayDateStr());
    if (usedSeconds >= timeLimits[domain] * 60) {
      redirectToBlocked("timelimit", { site: domain });
      return true;
    }

    initTimeTracking(domain, timeLimits[domain]);
    return false;
  }

  // -------------------------------------------------------------------
  // Main flow
  // -------------------------------------------------------------------

  hidePage();
  const revealTimeout = setTimeout(showPage, 4000);

  chrome.storage.local.get(
    ["protectionEnabled", "contentKeywords", "tempUnlocks", "timeLimits", "timeUsage"],
    data => {
      const enabled = data.protectionEnabled !== false;
      const keywords = (data.contentKeywords || [])
        .map(k => (k || "").toLowerCase().trim())
        .filter(Boolean);
      const tempUnlocks = data.tempUnlocks || {};
      const unlockedHere = tempUnlocks[currentHost] && tempUnlocks[currentHost] > Date.now();

      watchForBlockListChanges();

      if (!enabled || keywords.length === 0 || unlockedHere) {
        if (maybeInitTimeTracking(data)) return; // budget already spent
        clearTimeout(revealTimeout);
        showPage();
        return;
      }

      function scanForMatch() {
        const text = (
          document.title + " " + (document.body ? document.body.innerText : "")
        ).toLowerCase();
        for (const kw of keywords) {
          if (kw && text.includes(kw)) return kw;
        }
        return null;
      }

      function runInitialScan() {
        const match = scanForMatch();
        if (match) {
          redirectToBlocked("content", { kw: match });
        } else {
          if (maybeInitTimeTracking(data)) return; // budget already spent
          clearTimeout(revealTimeout);
          showPage();
          watchForChanges();
        }
      }

      function watchForChanges() {
        let scheduled = false;
        const observer = new MutationObserver(() => {
          if (scheduled) return;
          scheduled = true;
          setTimeout(() => {
            scheduled = false;
            const match = scanForMatch();
            if (match) {
              observer.disconnect();
              redirectToBlocked("content", { kw: match });
            }
          }, 400);
        });
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          characterData: true
        });
      }

      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", runInitialScan, { once: true });
      } else {
        runInitialScan();
      }
    }
  );
})();
